LiDAR_Lite
=======================

A Python interface for the LiDAR-Lite v3 by Garmin.

----

This is the README file for the project.

